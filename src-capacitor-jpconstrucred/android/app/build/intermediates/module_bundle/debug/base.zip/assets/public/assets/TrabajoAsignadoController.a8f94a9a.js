import{by as o,s as a}from"./index.70185135.js";class n extends o{constructor(){super(a.trabajo_asignado)}}export{n as T};
