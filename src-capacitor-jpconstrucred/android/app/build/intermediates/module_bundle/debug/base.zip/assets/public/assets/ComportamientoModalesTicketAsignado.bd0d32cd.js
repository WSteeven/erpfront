import{a as o}from"./ComponenteModal.domain.9bc16b73.js";import{b as e}from"./BotonesTablaTicket.f7683bcc.js";class r extends o{constructor(){super(new e)}}export{r as C};
