import{by as r,s}from"./index.70185135.js";class n extends r{constructor(o){super(s[o])}}export{n as S};
