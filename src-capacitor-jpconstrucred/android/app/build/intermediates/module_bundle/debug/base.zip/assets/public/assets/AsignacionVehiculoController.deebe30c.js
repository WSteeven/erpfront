import{by as o,s}from"./index.70185135.js";class r extends o{constructor(){super(s.asignaciones_vehiculos)}}export{r as A};
