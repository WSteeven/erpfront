import{by as o,s as r}from"./index.70185135.js";class e extends o{constructor(){super(r.tipo_chargebacks)}}export{e as T};
