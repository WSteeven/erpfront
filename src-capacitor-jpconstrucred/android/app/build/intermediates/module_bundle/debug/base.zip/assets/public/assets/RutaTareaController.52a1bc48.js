import{by as r,s}from"./index.70185135.js";class t extends r{constructor(){super(s.rutas_tareas)}}export{t as R};
