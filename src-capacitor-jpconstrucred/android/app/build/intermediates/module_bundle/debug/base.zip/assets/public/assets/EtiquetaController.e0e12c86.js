import{by as s,s as t}from"./index.70185135.js";class r extends s{constructor(){super(t.etiquetas)}}export{r as E};
