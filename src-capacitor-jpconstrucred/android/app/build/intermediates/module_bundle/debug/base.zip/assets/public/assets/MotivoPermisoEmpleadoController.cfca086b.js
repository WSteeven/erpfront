import{by as o,s as e}from"./index.70185135.js";class t extends o{constructor(){super(e.motivo_permiso_empleado)}}export{t as M};
