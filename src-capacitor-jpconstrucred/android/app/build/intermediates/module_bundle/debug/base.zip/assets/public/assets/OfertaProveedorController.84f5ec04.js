import{by as r,s as o}from"./index.70185135.js";class t extends r{constructor(){super(o.ofertas_proveedores)}}export{t as O};
