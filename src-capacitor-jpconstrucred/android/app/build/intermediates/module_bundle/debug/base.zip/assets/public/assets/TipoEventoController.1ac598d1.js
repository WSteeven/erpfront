import{by as o,s}from"./index.70185135.js";class t extends o{constructor(){super(s.tipos_eventos)}}export{t as T};
