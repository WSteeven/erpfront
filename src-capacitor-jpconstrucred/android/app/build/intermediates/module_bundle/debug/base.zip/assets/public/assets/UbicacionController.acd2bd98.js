import{by as o,s}from"./index.70185135.js";class c extends o{constructor(){super(s.ubicaciones)}}export{c as U};
