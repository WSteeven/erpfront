import{by as o,s as r}from"./index.70185135.js";class t extends o{constructor(){super(r.departamentos)}}export{t as D};
