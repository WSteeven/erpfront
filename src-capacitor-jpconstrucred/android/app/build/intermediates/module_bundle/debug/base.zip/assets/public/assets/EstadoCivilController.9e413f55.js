import{by as o,s}from"./index.70185135.js";class e extends o{constructor(){super(s.estado_civil)}}export{e as E};
