import{by as r,s}from"./index.70185135.js";class o extends r{constructor(){super(s.clientes_prefacturas)}}export{o as C};
