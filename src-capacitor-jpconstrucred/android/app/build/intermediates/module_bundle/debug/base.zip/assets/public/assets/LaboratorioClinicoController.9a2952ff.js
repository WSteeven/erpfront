import{by as o,s as r}from"./index.70185135.js";class i extends o{constructor(){super(r.laboratorios_clinicos)}}export{i as L};
