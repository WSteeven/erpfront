import{by as r,s}from"./index.70185135.js";class n extends r{constructor(){super(s.transferencias_vehiculos)}}export{n as T};
