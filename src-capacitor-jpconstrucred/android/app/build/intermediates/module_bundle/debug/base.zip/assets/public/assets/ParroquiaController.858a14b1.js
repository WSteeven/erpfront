import{by as r,s as o}from"./index.70185135.js";class e extends r{constructor(){super(o.parroquias)}}export{e as P};
