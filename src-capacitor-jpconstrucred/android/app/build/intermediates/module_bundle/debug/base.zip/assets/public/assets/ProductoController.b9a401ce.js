import{by as o,s as r}from"./index.70185135.js";class e extends o{constructor(){super(r.productos)}}export{e as P};
