import{by as s,s as o}from"./index.70185135.js";class e extends s{constructor(){super(o.tickets)}}export{e as T};
