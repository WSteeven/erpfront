import{by as e,s as o}from"./index.70185135.js";class t extends e{constructor(){super(o.obtener_clientes_materiales_empleado)}}export{t as C};
