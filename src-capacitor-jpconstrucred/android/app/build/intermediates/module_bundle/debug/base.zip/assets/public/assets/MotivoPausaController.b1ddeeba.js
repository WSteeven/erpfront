import{by as o,s}from"./index.70185135.js";class t extends o{constructor(){super(s.motivos_pausas)}}export{t as M};
