import{bz as s,t as o}from"./index.846478c1.js";class e extends s{constructor(){super(o.transacciones_ingresos)}}export{e as T};
