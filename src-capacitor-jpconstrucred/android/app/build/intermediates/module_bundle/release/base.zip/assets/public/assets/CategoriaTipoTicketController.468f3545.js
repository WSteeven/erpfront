import{bz as o,t}from"./index.846478c1.js";class e extends o{constructor(){super(t.categorias_tipos_tickets)}}export{e as C};
