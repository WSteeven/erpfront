import{by as o,s as r}from"./index.70185135.js";class n extends o{constructor(){super(r.archivos)}}export{n as A};
