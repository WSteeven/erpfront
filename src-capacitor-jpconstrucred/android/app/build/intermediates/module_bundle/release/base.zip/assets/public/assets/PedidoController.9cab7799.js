import{by as o,s}from"./index.70185135.js";class n extends o{constructor(){super(s.pedidos)}}export{n as P};
