import{by as o,s}from"./index.70185135.js";class t extends o{constructor(){super(s.postulacion_vacante)}}export{t as P};
