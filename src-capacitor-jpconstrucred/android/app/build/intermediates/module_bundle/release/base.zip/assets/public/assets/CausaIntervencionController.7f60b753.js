import{bz as n,t as s}from"./index.846478c1.js";class r extends n{constructor(){super(s.causas_intervenciones)}}export{r as C};
