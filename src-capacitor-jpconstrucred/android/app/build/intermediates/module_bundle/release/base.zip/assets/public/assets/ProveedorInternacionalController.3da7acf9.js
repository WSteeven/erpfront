import{bz as o,t as r}from"./index.846478c1.js";class s extends o{constructor(){super(r.proveedores_internacionales)}}export{s as P};
