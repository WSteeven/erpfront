import{bz as o,t as r}from"./index.846478c1.js";class a extends o{constructor(){super(r.laboratorios_clinicos)}}export{a as L};
