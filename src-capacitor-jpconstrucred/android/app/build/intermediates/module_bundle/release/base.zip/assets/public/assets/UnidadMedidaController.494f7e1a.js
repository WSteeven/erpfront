import{by as s,s as e}from"./index.70185135.js";class a extends s{constructor(){super(e.unidades_medidas)}}export{a as U};
