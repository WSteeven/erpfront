import{by as s,s as o}from"./index.70185135.js";class t extends s{constructor(){super(o.etapas)}}export{t as E};
