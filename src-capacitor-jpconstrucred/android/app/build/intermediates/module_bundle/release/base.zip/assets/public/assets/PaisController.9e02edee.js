import{bz as s,t as o}from"./index.846478c1.js";class t extends s{constructor(){super(o.paises)}}export{t as P};
