import{by as o,s}from"./index.70185135.js";class n extends o{constructor(){super(s.links_cuestionarios_publicos)}}export{n as L};
