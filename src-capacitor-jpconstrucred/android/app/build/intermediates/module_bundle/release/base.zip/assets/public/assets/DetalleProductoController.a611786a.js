import{by as o,s as e}from"./index.70185135.js";class t extends o{constructor(){super(e.detalles)}}export{t as D};
