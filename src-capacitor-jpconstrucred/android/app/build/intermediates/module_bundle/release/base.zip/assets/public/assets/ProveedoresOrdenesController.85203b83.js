import{by as e,s as r}from"./index.70185135.js";class n extends e{constructor(){super(r.proveedores_ordenes)}}export{n as P};
