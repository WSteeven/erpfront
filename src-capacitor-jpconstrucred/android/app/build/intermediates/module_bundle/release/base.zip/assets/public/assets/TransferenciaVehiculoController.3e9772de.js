import{bz as r,t as e}from"./index.846478c1.js";class n extends r{constructor(){super(e.transferencias_vehiculos)}}export{n as T};
