import{bz as r,t as a}from"./index.846478c1.js";class o extends r{constructor(){super(a.rutas_tareas)}}export{o as R};
