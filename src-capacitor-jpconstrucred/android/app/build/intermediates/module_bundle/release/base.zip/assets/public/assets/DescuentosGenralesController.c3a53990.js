import{by as e,s}from"./index.70185135.js";class n extends e{constructor(){super(s.descuentos_generales)}}export{n as D};
