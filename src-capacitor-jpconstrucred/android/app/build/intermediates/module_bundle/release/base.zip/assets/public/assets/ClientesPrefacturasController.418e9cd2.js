import{bz as r,t as e}from"./index.846478c1.js";class o extends r{constructor(){super(e.clientes_prefacturas)}}export{o as C};
