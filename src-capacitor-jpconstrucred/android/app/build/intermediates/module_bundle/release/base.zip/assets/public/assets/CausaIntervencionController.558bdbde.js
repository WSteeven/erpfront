import{by as s,s as n}from"./index.70185135.js";class r extends s{constructor(){super(n.causas_intervenciones)}}export{r as C};
