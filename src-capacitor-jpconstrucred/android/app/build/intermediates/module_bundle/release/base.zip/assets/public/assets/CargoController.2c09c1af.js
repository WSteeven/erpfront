import{bz as o,t as r}from"./index.846478c1.js";class a extends o{constructor(){super(r.cargos)}}export{a as C};
