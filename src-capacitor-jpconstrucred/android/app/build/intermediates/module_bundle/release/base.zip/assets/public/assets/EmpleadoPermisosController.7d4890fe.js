import{bz as o,t as s}from"./index.846478c1.js";class t extends o{constructor(){super(s.empleados_permisos)}}export{t as E};
