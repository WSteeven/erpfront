import{by as o,s}from"./index.70185135.js";class e extends o{constructor(){super(s.nodos)}}export{e as N};
