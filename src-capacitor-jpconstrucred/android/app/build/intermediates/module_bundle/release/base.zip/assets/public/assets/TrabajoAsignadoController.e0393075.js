import{bz as o,t as a}from"./index.846478c1.js";class n extends o{constructor(){super(a.trabajo_asignado)}}export{n as T};
