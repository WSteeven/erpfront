import{by as r,s}from"./index.70185135.js";class e extends r{constructor(){super(s.marcas)}}export{e as M};
