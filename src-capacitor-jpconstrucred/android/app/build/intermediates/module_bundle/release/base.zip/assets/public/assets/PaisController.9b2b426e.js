import{by as s,s as o}from"./index.70185135.js";class a extends s{constructor(){super(o.paises)}}export{a as P};
