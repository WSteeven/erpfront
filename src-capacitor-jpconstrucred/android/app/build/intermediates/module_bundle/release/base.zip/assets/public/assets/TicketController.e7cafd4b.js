import{bz as t,t as o}from"./index.846478c1.js";class e extends t{constructor(){super(o.tickets)}}export{e as T};
