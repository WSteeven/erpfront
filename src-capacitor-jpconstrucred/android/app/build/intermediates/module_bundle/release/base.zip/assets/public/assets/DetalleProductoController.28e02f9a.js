import{bz as o,t as e}from"./index.846478c1.js";class s extends o{constructor(){super(e.detalles)}}export{s as D};
