import{bz as o,t as e}from"./index.846478c1.js";class l extends o{constructor(){super(e.empleados_roles)}}export{l as E};
