import{bz as r,t as o}from"./index.846478c1.js";class e extends r{constructor(){super(o.garajes)}}export{e as G};
