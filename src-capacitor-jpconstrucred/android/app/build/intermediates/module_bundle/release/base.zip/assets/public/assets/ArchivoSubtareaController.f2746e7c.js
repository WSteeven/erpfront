import{by as r,s}from"./index.70185135.js";class e extends r{constructor(){super(s.archivos_subtareas)}}export{e as A};
