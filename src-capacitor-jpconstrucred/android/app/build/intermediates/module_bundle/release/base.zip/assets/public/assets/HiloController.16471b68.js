import{by as o,s}from"./index.70185135.js";class l extends o{constructor(){super(s.hilos)}}export{l as H};
