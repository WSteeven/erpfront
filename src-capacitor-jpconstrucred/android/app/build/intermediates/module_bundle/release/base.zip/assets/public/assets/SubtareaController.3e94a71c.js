import{bz as r,t as s}from"./index.846478c1.js";class a extends r{constructor(){super(s.subtareas)}}export{a as S};
