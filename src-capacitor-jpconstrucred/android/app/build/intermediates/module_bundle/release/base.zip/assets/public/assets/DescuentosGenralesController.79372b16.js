import{bz as e,t as s}from"./index.846478c1.js";class n extends e{constructor(){super(s.descuentos_generales)}}export{n as D};
