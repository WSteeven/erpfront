import{bz as s,t as o}from"./index.846478c1.js";class n extends s{constructor(){super(o.planes)}}export{n as P};
