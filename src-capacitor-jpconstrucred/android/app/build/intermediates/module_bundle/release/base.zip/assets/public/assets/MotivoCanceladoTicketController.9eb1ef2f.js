import{bz as o,t}from"./index.846478c1.js";class r extends o{constructor(){super(t.motivos_cancelados_tickets)}}export{r as M};
