import{by as s,s as o}from"./index.70185135.js";class n extends s{constructor(){super(o.planes)}}export{n as P};
