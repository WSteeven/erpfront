import{bz as e,t as o}from"./index.846478c1.js";class a extends e{constructor(){super(o.obtener_clientes_materiales_empleado)}}export{a as C};
