import{bz as e,t as r}from"./index.846478c1.js";class n extends e{constructor(){super(r.proveedores_ordenes)}}export{n as P};
