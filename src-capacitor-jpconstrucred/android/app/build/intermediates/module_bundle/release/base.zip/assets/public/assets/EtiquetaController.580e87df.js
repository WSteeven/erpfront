import{bz as t,t as e}from"./index.846478c1.js";class s extends t{constructor(){super(e.etiquetas)}}export{s as E};
