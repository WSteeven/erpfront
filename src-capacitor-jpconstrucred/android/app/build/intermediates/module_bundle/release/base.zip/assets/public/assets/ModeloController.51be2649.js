import{by as o,s}from"./index.70185135.js";class l extends o{constructor(){super(s.modelos)}}export{l as M};
