import{bz as o,t as r}from"./index.846478c1.js";class t extends o{constructor(){super(r.banco)}}export{t as B};
