import{a as o}from"./ComponenteModal.domain.3bd8db1f.js";import{b as e}from"./BotonesTablaTicket.01fac7eb.js";class r extends o{constructor(){super(new e)}}export{r as C};
