import{by as o,s as e}from"./index.70185135.js";class l extends o{constructor(){super(e.empleados_roles)}}export{l as E};
