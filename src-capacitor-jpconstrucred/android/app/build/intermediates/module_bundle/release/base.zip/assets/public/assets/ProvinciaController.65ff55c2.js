import{by as o,s as r}from"./index.70185135.js";class a extends o{constructor(){super(r.provincias)}}export{a as P};
