import{by as e,s}from"./index.70185135.js";class n extends e{constructor(){super(s.clientes)}}export{n as C};
