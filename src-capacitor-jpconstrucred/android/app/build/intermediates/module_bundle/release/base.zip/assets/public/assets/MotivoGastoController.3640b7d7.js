import{bz as o,t}from"./index.846478c1.js";class a extends o{constructor(){super(t.motivo_gasto)}}export{a as M};
