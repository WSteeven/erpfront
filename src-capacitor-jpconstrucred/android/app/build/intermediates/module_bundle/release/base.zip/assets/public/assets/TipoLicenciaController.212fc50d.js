import{by as o,s as r}from"./index.70185135.js";class i extends o{constructor(){super(r.tipo_licencia)}}export{i as T};
