import{bz as r,t as o}from"./index.846478c1.js";class e extends r{constructor(){super(o.tareas)}}export{e as T};
