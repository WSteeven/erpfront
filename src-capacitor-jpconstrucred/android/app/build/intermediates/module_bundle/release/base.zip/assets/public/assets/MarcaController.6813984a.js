import{bz as r,t as o}from"./index.846478c1.js";class t extends r{constructor(){super(o.marcas)}}export{t as M};
