import{bz as o,t as s}from"./index.846478c1.js";class a extends o{constructor(){super(s.gastos)}}export{a as G};
