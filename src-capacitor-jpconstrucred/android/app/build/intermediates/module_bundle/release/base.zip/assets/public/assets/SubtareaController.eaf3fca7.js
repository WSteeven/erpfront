import{by as r,s}from"./index.70185135.js";class e extends r{constructor(){super(s.subtareas)}}export{e as S};
