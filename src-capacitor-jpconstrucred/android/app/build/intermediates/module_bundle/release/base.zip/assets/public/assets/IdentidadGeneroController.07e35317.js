import{bz as e,t as o}from"./index.846478c1.js";class s extends e{constructor(){super(o.identidades_generos)}}export{s as I};
