import{by as o,s}from"./index.70185135.js";class a extends o{constructor(){super(s.tipos_transacciones)}}export{a as T};
