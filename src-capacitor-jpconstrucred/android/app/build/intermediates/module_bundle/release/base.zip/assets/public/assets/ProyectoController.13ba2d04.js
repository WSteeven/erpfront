import{bz as o,t as r}from"./index.846478c1.js";class e extends o{constructor(){super(r.proyectos)}}export{e as P};
