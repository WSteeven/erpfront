import{bz as r,t as e}from"./index.846478c1.js";class n extends r{constructor(o){super(e[o])}}export{n as S};
