import{bz as a,t as r}from"./index.846478c1.js";class o extends a{constructor(){super(r.adm_cuentas_bancarias)}}export{o as C};
