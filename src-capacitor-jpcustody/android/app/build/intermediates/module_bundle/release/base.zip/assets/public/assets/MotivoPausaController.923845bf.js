import{by as o,s}from"./index.b8e09611.js";class t extends o{constructor(){super(s.motivos_pausas)}}export{t as M};
