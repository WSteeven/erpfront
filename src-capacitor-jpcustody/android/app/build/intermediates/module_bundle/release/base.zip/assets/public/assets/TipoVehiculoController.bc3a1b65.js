import{by as o,s}from"./index.b8e09611.js";class t extends o{constructor(){super(s.tipos_vehiculos)}}export{t as T};
