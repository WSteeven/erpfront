import{by as o,s as r}from"./index.b8e09611.js";class e extends o{constructor(){super(r.movilizacion_subtarea)}}export{e as M};
