import{by as o,s as r}from"./index.b8e09611.js";class s extends o{constructor(){super(r.proveedores_internacionales)}}export{s as P};
