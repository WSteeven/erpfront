import{by as s,s as t}from"./index.b8e09611.js";class r extends s{constructor(){super(t.etiquetas)}}export{r as E};
