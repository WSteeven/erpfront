import{by as s,s as e}from"./index.b8e09611.js";class a extends s{constructor(){super(e.unidades_medidas)}}export{a as U};
