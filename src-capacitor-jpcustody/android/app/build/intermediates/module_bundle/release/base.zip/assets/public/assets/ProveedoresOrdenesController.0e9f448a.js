import{by as e,s as r}from"./index.b8e09611.js";class n extends e{constructor(){super(r.proveedores_ordenes)}}export{n as P};
