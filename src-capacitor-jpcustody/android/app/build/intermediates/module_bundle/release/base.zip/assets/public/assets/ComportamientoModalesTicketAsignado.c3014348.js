import{a as o}from"./ComponenteModal.domain.92aacded.js";import{b as e}from"./BotonesTablaTicket.151fa3b2.js";class r extends o{constructor(){super(new e)}}export{r as C};
