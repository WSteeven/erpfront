import{by as o,s}from"./index.b8e09611.js";class e extends o{constructor(){super(s.estado_civil)}}export{e as E};
