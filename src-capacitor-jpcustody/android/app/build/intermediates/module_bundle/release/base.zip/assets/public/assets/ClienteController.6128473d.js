import{by as e,s}from"./index.b8e09611.js";class n extends e{constructor(){super(s.clientes)}}export{n as C};
