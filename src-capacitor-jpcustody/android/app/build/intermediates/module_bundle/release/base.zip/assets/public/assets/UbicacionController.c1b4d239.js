import{by as o,s}from"./index.b8e09611.js";class c extends o{constructor(){super(s.ubicaciones)}}export{c as U};
