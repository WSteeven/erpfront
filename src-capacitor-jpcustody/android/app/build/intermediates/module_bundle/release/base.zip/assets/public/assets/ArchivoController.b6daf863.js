import{by as o,s as r}from"./index.b8e09611.js";class n extends o{constructor(){super(r.archivos)}}export{n as A};
