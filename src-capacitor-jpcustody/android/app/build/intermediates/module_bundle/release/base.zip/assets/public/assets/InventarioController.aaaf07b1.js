import{by as o,s as r}from"./index.b8e09611.js";class e extends o{constructor(){super(r.inventarios)}}export{e as I};
