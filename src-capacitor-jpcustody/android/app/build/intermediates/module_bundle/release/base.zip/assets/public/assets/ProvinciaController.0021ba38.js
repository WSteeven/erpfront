import{by as o,s as r}from"./index.b8e09611.js";class a extends o{constructor(){super(r.provincias)}}export{a as P};
