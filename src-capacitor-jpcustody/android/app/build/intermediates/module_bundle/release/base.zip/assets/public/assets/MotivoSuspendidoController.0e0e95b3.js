import{by as o,s}from"./index.b8e09611.js";class n extends o{constructor(){super(s.motivos_suspendidos)}}export{n as M};
