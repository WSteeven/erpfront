import{by as s,s as o}from"./index.b8e09611.js";class e extends s{constructor(){super(o.tickets)}}export{e as T};
