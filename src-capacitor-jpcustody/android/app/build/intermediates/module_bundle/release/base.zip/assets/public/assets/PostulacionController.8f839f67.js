import{by as o,s}from"./index.b8e09611.js";class t extends o{constructor(){super(s.postulacion_vacante)}}export{t as P};
