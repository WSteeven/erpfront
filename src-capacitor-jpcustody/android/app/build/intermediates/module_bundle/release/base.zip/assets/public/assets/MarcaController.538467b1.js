import{by as r,s}from"./index.b8e09611.js";class e extends r{constructor(){super(s.marcas)}}export{e as M};
