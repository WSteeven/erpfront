import{by as o,s}from"./index.b8e09611.js";class r extends o{constructor(){super(s.motivos_cancelados_tickets)}}export{r as M};
