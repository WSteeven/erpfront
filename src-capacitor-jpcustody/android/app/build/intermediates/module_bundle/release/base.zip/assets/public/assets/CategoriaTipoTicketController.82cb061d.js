import{by as o,s}from"./index.b8e09611.js";class e extends o{constructor(){super(s.categorias_tipos_tickets)}}export{e as C};
