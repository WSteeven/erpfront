import{by as s,s as o}from"./index.b8e09611.js";class a extends s{constructor(){super(o.motivos_pausas_tickets)}}export{a as M};
