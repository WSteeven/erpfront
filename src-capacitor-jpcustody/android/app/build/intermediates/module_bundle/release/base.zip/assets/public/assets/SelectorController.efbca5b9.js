import{by as r,s}from"./index.b8e09611.js";class n extends r{constructor(o){super(s[o])}}export{n as S};
