import{by as o,s}from"./index.b8e09611.js";class a extends o{constructor(){super(s.motivo_gasto)}}export{a as M};
