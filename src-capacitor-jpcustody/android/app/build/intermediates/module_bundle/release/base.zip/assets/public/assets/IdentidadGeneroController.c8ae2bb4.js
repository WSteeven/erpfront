import{by as e,s as o}from"./index.b8e09611.js";class n extends e{constructor(){super(o.identidades_generos)}}export{n as I};
