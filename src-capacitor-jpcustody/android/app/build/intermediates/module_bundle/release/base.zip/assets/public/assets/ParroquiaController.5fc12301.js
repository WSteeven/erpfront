import{by as r,s as o}from"./index.b8e09611.js";class e extends r{constructor(){super(o.parroquias)}}export{e as P};
