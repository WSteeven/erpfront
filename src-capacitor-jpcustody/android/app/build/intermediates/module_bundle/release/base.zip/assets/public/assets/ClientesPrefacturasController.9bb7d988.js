import{by as r,s}from"./index.b8e09611.js";class o extends r{constructor(){super(s.clientes_prefacturas)}}export{o as C};
