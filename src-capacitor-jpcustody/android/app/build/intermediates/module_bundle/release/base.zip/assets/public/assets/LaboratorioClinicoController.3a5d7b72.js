import{by as o,s as r}from"./index.b8e09611.js";class i extends o{constructor(){super(r.laboratorios_clinicos)}}export{i as L};
