import{by as o,s as r}from"./index.b8e09611.js";class d extends o{constructor(){super(r.modalidad)}}export{d as M};
