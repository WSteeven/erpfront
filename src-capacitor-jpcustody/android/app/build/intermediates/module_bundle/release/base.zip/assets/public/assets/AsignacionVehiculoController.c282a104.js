import{by as o,s}from"./index.b8e09611.js";class r extends o{constructor(){super(s.asignaciones_vehiculos)}}export{r as A};
