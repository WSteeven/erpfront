import{by as s,s as o}from"./index.b8e09611.js";class t extends s{constructor(){super(o.etapas)}}export{t as E};
