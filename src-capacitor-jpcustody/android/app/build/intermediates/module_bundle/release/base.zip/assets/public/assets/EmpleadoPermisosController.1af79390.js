import{by as o,s}from"./index.b8e09611.js";class a extends o{constructor(){super(s.empleados_permisos)}}export{a as E};
