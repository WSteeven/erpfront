import{by as r,s}from"./index.b8e09611.js";class t extends r{constructor(){super(s.rutas_tareas)}}export{t as R};
