import{by as o,s as r}from"./index.b8e09611.js";class t extends o{constructor(){super(r.tipo_fondo)}}export{t as T};
