import{by as s,s as o}from"./index.b8e09611.js";class n extends s{constructor(){super(o.planes)}}export{n as P};
