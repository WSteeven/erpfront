import{by as o,s as e}from"./index.b8e09611.js";class t extends o{constructor(){super(e.detalles)}}export{t as D};
