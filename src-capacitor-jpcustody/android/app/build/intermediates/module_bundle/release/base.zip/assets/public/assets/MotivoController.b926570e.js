import{by as o,s}from"./index.b8e09611.js";class e extends o{constructor(){super(s.motivos)}}export{e as M};
