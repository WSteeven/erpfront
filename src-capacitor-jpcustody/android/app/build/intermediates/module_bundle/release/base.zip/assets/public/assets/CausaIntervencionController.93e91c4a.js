import{by as s,s as n}from"./index.b8e09611.js";class r extends s{constructor(){super(n.causas_intervenciones)}}export{r as C};
