import{by as r,s}from"./index.b8e09611.js";class e extends r{constructor(){super(s.archivos_subtareas)}}export{e as A};
