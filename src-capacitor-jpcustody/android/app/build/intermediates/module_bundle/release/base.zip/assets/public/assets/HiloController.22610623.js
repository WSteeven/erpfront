import{by as o,s}from"./index.b8e09611.js";class l extends o{constructor(){super(s.hilos)}}export{l as H};
