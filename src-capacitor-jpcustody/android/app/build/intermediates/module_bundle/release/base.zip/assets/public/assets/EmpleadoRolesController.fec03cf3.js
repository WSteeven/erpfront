import{by as o,s as e}from"./index.b8e09611.js";class l extends o{constructor(){super(e.empleados_roles)}}export{l as E};
