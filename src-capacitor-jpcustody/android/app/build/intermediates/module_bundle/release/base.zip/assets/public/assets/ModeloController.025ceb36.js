import{by as o,s}from"./index.b8e09611.js";class l extends o{constructor(){super(s.modelos)}}export{l as M};
