<template>
  <q-page :padding="!$q.screen.xs">
    <div class="text-center q-pb-md">
      <div class="q-mb-md">{{ fecha }}</div>
      <div class="q-mb-md">
        Bienvenido, <strong>{{ authenticationStore.nombreUsuario }}</strong>
      </div>
      <div v-if="authenticationStore.user?.grupo" class="q-mb-md">
        Grupo, <strong>{{ authenticationStore.user.grupo }}</strong>
      </div>
    </div>

    <essential-table-tabs
      :configuracionColumnas="[
        ...configuracionColumnasAutorizarGasto,
        accionesTabla,
      ]"
      :datos="listado"
      :accion1="botonVerModalGasto"
      :permitirConsultar="false"
      :permitirEditar="false"
      :permitirEliminar="false"
      :permitirBuscar="false"
      :mostrar-botones="false"
      :tab-options="tabAutorizarGasto"
      @tab-seleccionado="filtrarAutorizacionesGasto"
      tab-defecto="PENDIENTE"
    ></essential-table-tabs>
    <modal-entidad
    :comportamiento="modales"
    @guardado="guardado"
    >
  <template>
    <div class="q-pa-md q-gutter-sm flex flex-center"
        v-if="usuario.id == gasto.aut_especial && gasto.estado_info == 'POR APROBAR'">
        <q-btn color="positive" @click="aprobar_gasto(gasto, 'aprobar')">
          <q-icon name="bi-check-circle" size="xs"></q-icon>Aprobar</q-btn>
        <q-btn color="negative" @click="aprobar_gasto(gasto, 'rechazar')">
          <q-icon name="bi-x-circle" size="xs"></q-icon>Rechazar</q-btn>
      </div>
      <div class="q-pa-md q-gutter-sm flex flex-center"
        v-if="usuario.id == gasto.aut_especial && gasto.estado_info == 'APROBADO' && estaSemanAC==true">
        <q-btn color="negative" @click="aprobar_gasto(gasto, 'anular')">
          <q-icon name="bi-x-circle" size="xs"></q-icon>Anular</q-btn>
      </div>
  </template>
  </modal-entidad>
  </q-page>
</template>

<script src="./AutorizarGastoPage.ts"></script>
