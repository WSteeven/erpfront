<template>
  <tab-layout
    :mixin="mixin"
    :configuracionColumnas="configuracionColumnas"
    titulo-pagina="Control de productos en perchas"
  >
    <template #formulario>
      <q-form @submit.prevent>
        <div class="row q-col-gutter-sm q-py-md">
          <!-- Sucursal select -->
          <div class="col-12 col-md-6">
            <label class="q-mb-sm block">Sucursal</label>
            <q-select
              v-model="sucursal"
              :options="opciones_sucursales"
              transition-show="jump-up"
              transition-hide="jump-up"
              options-dense
              dense
              outlined
              @update:model-value="SucursalSeleccionada"
              error-message="Debes seleccionar una sucursal"
              :option-label="(item) => item.lugar"
              :option-value="(item) => item.id"
              emit-value
              map-options
            >
              <template v-slot:no-option>
                <q-item>
                  <q-item-section class="text-grey">
                    No hay resultados
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
          </div>
          <!-- Inventario select -->
          <div class="col-12 col-md-6">
            <label class="q-mb-sm block">Inventario</label>
            <div class="row">
              <div class="col-12 col-md-8 q-mb-md">
                <q-input
                  v-model="criterioBusquedaInventario"
                  placeholder="Producto del inventario"
                  hint="Presiona Enter para seleccionar un producto"
                  @keydown.enter="listarInventarios({ sucursal_id: sucursal })"
                  @blur="
                    criterioBusquedaInventario === ''
                      ? limpiarInventario()
                      : null
                  "
                  dense
                  outlined
                >
                </q-input>
              </div>
              <div class="col-12 col-md-4">
                <q-btn
                  @click="listarInventarios({ sucursal_id: sucursal })"
                  icon="search"
                  unelevated
                  color="secondary"
                  class="full-width"
                  style="height: 40px"
                  no-caps
                  >Buscar</q-btn
                >
              </div>
            </div>
          </div>
          <!-- Ubicacion select -->
          <div class="col-12 col-md-6">
            <label class="q-mb-sm block">Ubicación</label>
            <q-select
              v-model="producto_percha.ubicacion"
              :options="opciones_ubicaciones"
              transition-show="jump-up"
              transition-hide="jump-up"
              options-dense
              dense
              outlined
              :error="!!v$.ubicacion.$errors.length"
              error-message="Debes seleccionar una ubicación"
              :option-label="(item) => item.codigo"
              :option-value="(item) => item.id"
              emit-value
              map-options
            >
              <template v-slot:option="scope">
                <q-item v-bind="scope.itemProps">
                  <q-item-section>
                    <q-item-label>{{ scope.opt.codigo }}</q-item-label>
                    <q-item-label caption
                      >Piso:{{ scope.opt.piso }} | Percha:{{
                        scope.opt.percha
                      }}
                      | Sucursal:{{ scope.opt.sucursal }}</q-item-label
                    >
                  </q-item-section>
                </q-item>
              </template>
              <template v-slot:error>
                <div v-for="error of v$.ubicacion.$errors" :key="error.$uid">
                  <div class="error-msg">{{ error.$message }}</div>
                </div>
              </template>
              <template v-slot:no-option>
                <q-item>
                  <q-item-section class="text-grey">
                    No hay resultados
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
          </div>
          <!-- Cantidad -->
          <div class="col-12 col-md-6">
            <label class="q-mb-sm block">Cantidad</label>
            <q-input
              type="number"
              v-model="producto_percha.stock"
              placeholder="Obligatorio"
              :readonly="disabled"
              :error="!!v$.stock.$errors.length"
              outlined
              dense
            >
              <template v-slot:error>
                <div v-for="error of v$.stock.$errors" :key="error.$uid">
                  <div class="error-msg">{{ error.$message }}</div>
                </div>
              </template>
            </q-input>
          </div>
        </div>
      </q-form>

      <essential-selectable-table
        ref="refListadoSeleccionableInventarios"
        :configuracion-columnas="configuracionColumnasInventarios"
        :datos="listadoInventarios"
        @selected="seleccionarInventario"
      >
      </essential-selectable-table>
    </template>
  </tab-layout>
</template>
<script src="./ProductosPerchaPage.ts"></script>
