<template>
  <small v-if="$q.screen.xs" class="text-bold text-negative block"
    >*Deslice la tabla hacia los lados para observar más información</small
  >
</template>

<script lang="ts" setup></script>
