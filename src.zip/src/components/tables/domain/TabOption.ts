export interface TabOption {
  label: string,
  value: any
}
