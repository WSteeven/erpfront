export class Filtro {
  field: string | null
  label: string | null
  value: string | null

  constructor() {
    this.field = null
    this.label = null
    this.value = null
  }
}
