<template>
  <small class="q-pa-xs text-right">
    <strong>Copyright © 2023</strong>. Todos los derechos reservados por
    <strong>JPCONSTRUCRED</strong>.
  </small>
</template>

<style>
.footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  width: 100%;
}
</style>
