export const plantillas = {
    INSTALACION: 'INSTALACION',
    EMERGENCIA: 'EMERGENCIA',
    DESMONTAJE: 'DESMONTAJE',
}
