export interface ParamsType {
    [key: string]: any
}