export const opciones_traccion_vehiculos = [
    { value: '4X2 FWD', label: '4X2 FWD' },
    { value: '4X2 RWD', label: '4X2 RWD' },
    { value: 'AWD', label: 'AWD' },
    { value: '4WD', label: '4WD' },
    { value: '4X4', label: '4X4' },
  ]
  