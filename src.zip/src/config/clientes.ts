export const clientes = {
  TELCONET: 2,
  NEDETEL: 3,
}
